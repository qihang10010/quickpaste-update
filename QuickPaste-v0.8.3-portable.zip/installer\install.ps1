$ErrorActionPreference = "Stop"

$sourceRoot = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$installDir = Join-Path $env:LOCALAPPDATA "QuickPaste"
$exeSource = Join-Path $sourceRoot "QuickPaste.exe"
$exeTarget = Join-Path $installDir "QuickPaste.exe"
$assetsSource = Join-Path $sourceRoot "assets"
$assetsTarget = Join-Path $installDir "assets"

if (!(Test-Path $exeSource)) {
    throw "未找到 QuickPaste.exe，请从便携版目录中的 installer 文件夹运行本脚本。"
}

Get-Process -Name "QuickPaste" -ErrorAction SilentlyContinue | Stop-Process -Force

New-Item -ItemType Directory -Force -Path $installDir | Out-Null
Copy-Item -LiteralPath $exeSource -Destination $exeTarget -Force
if (Test-Path $assetsSource) {
    New-Item -ItemType Directory -Force -Path $assetsTarget | Out-Null
    Copy-Item -Path (Join-Path $assetsSource "*") -Destination $assetsTarget -Force
}

$desktop = [Environment]::GetFolderPath("DesktopDirectory")
$shortcutPath = Join-Path $desktop "快捷粘贴.lnk"
$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut($shortcutPath)
$shortcut.TargetPath = $exeTarget
$shortcut.WorkingDirectory = $installDir
$shortcut.IconLocation = $exeTarget
$shortcut.Save()

Start-Process -FilePath $exeTarget
Write-Host "安装完成：$exeTarget"
