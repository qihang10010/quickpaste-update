$ErrorActionPreference = "Stop"

$installDir = Join-Path $env:LOCALAPPDATA "QuickPaste"
$desktop = [Environment]::GetFolderPath("DesktopDirectory")
$shortcutPath = Join-Path $desktop "快捷粘贴.lnk"

Get-Process -Name "QuickPaste" -ErrorAction SilentlyContinue | Stop-Process -Force

if (Test-Path $shortcutPath) {
    Remove-Item -LiteralPath $shortcutPath -Force
}

if (Test-Path $installDir) {
    Remove-Item -LiteralPath $installDir -Recurse -Force
}

Write-Host "卸载完成。"
